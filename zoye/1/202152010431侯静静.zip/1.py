import os

import matplotlib.pyplot as plt
import pandas as pd

df = pd.read_excel('成绩表.xlsx')
df.to_csv('csv1.csv', header=False, index=False)

plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

num1 = open("csv1.csv", mode='r', encoding='utf8', )
numa = num1.readlines()
num1.close()
os_path = './img/'
os.mkdir('./img/')
for line in numa:
    nums = line.split(",")
    name = nums[0]
    a = int(nums[1])
    b = int(nums[2])
    c = int(nums[3])
    x = ["平时成绩", "实验成绩", "卷面成绩"]
    y = [a, b, c]
    plt.bar(x, y)
    plt.title(name)
    plt.savefig('./img/' + name + '.png')
